<?php
defined('_JEXEC') or die;

// Variables from mod file
$ribbonEnable = (int) $params->get('ribbon_enable', 1);
$position     = ModBlackRibbonHelper::sanitizePosition($params->get('position', 'top-right'));
$width        = htmlspecialchars($params->get('width', '90px'), ENT_QUOTES, 'UTF-8');
$height       = htmlspecialchars($params->get('height', '90px'), ENT_QUOTES, 'UTF-8');
$zIndex       = ModBlackRibbonHelper::sanitizeInt($params->get('z_index', 9999), 0, 2147483647, 9999);
$descRaw      = (string) $params->get('description', '');
$desc         = htmlspecialchars($descRaw, ENT_QUOTES, 'UTF-8');

$ribbonUrl    = htmlspecialchars($ribbonUrl, ENT_QUOTES, 'UTF-8');

$grayEnable = (int) $params->get('grayscale_enable', 0);
$grayAmount = (int) $params->get('grayscale_amount', 100);
if ($grayAmount < 0)  $grayAmount = 0;
if ($grayAmount > 100) $grayAmount = 100;

// Popup (escaped)
$popupEnable      = (int) $params->get('popup_enable', 0);
$popupImgUrl      = htmlspecialchars((string) $params->get('popup_image_url', ''), ENT_QUOTES, 'UTF-8');
$popupWidth       = htmlspecialchars((string) $params->get('popup_width', '720px'), ENT_QUOTES, 'UTF-8');
$popupHeight      = htmlspecialchars((string) $params->get('popup_height', 'auto'), ENT_QUOTES, 'UTF-8');
$popupMaxShows    = (int) $params->get('popup_max_shows', 1);
$popupResetDays   = (int) $params->get('popup_reset_days', 30);
$popupDelayMs     = (int) $params->get('popup_delay_ms', 300);
$popupAutoCloseMs = (int) $params->get('popup_auto_close_ms', 0);
$popupCloseText   = htmlspecialchars((string) $params->get('popup_close_text', 'Close'), ENT_QUOTES, 'UTF-8');
$popupBgOpacity   = (float) $params->get('popup_bg_opacity', 0.8);
if ($popupBgOpacity < 0) $popupBgOpacity = 0;
if ($popupBgOpacity > 1) $popupBgOpacity = 1;
$popupClickUrl    = htmlspecialchars((string) $params->get('popup_click_url', ''), ENT_QUOTES, 'UTF-8');
?>
<style>
<?php if ($ribbonEnable): ?>
/* Ribbon (per-position image; no transforms needed) */
.brb-ribbon {
  position: fixed;
  width: <?php echo $width; ?>;
  height: <?php echo $height; ?>;
  background: url('<?php echo $ribbonUrl; ?>') no-repeat center;
  background-size: contain;
  z-index: <?php echo $zIndex; ?>;
  pointer-events: none;
}
.brb-pos-top-left    { top: 0; left: 0; }
.brb-pos-top-right   { top: 0; right: 0; }
.brb-pos-bottom-left { bottom: 0; left: 0; }
.brb-pos-bottom-right{ bottom: 0; right: 0; }
<?php endif; ?>

<?php if ($grayEnable): ?>
html {
  -webkit-filter: grayscale(<?php echo $grayAmount; ?>%) !important;
          filter: grayscale(<?php echo $grayAmount; ?>%) !important;
}
<?php endif; ?>

/* Popup styles */
#brb-popup-overlay {
  display: none;
  position: fixed; left: 0; top: 0; width: 100%; height: 100%;
  background: rgba(0,0,0,<?php echo $popupBgOpacity; ?>);
  z-index: 2147483647;
}
#brb-popup-dialog {
  position: absolute; left: 50%; top: 50%;
  transform: translate(-50%, -50%);
  outline: none;
}
#brb-popup-dialog img {
  display: block;
  width: <?php echo $popupWidth; ?>;
  height: <?php echo $popupHeight; ?>;
  max-width: 95vw;
  max-height: 90vh;
}
#brb-popup-close {
  position: absolute; right: 8px; top: 8px;
  background: rgba(0,0,0,.6);
  color: #fff; border: 0; padding: 6px 10px; cursor: pointer;
  font-size: 14px; border-radius: 4px;
}
.brb-sr-only {
  position: absolute !important;
  width: 1px !important;
  height: 1px !important;
  padding: 0 !important;
  margin: -1px !important;
  overflow: hidden !important;
  clip: rect(0, 0, 0, 0) !important;
  white-space: nowrap !important;
  border: 0 !important;
}
</style>

<?php if ($ribbonEnable): ?>
<div class="brb-ribbon brb-pos-<?php echo $position; ?>" role="img" aria-label="<?php echo $desc; ?>" title="<?php echo $desc; ?>"></div>
<?php if ($desc !== ''): ?><span class="brb-sr-only"><?php echo $desc; ?></span><?php endif; ?>
<?php endif; ?>

<?php if ($popupEnable): ?>
<div id="brb-popup-overlay" role="dialog" aria-modal="true" aria-label="Popup image dialog" tabindex="-1">
  <div id="brb-popup-dialog">
    <button id="brb-popup-close" type="button"><?php echo $popupCloseText; ?></button>
    <?php if ($popupClickUrl !== ''): ?>
      <a href="<?php echo $popupClickUrl; ?>" target="_blank" rel="noopener">
        <img src="<?php echo $popupImgUrl; ?>" alt="popup image"/>
      </a>
    <?php else: ?>
      <img src="<?php echo $popupImgUrl; ?>" alt="popup image"/>
    <?php endif; ?>
  </div>
</div>

<script>
(function(){
  var maxShows   = <?php echo (int)$popupMaxShows; ?>;
  var resetDays  = <?php echo (int)$popupResetDays; ?>;
  var delayMs    = <?php echo (int)$popupDelayMs; ?>;
  var autoClose  = <?php echo (int)$popupAutoCloseMs; ?>;
  var KEY        = 'mod_blackribbon_popup_v122';
  var autoTimer  = null;
  function now() { return (new Date()).getTime(); }
  function days(ms){ return Math.floor(ms / (24*60*60*1000)); }

  function getData() {
    try { var raw = localStorage.getItem(KEY); if (raw) return JSON.parse(raw); } catch(e){}
    var m = document.cookie.match(new RegExp(KEY+'=([^;]+)'));
    if (m && m[1]) { try { return JSON.parse(decodeURIComponent(m[1])); } catch(e){} }
    return {count:0,last:0};
  }

  function setData(obj) {
    try { localStorage.setItem(KEY, JSON.stringify(obj)); } catch(e){}
    try {
      var exp = new Date(); exp.setDate(exp.getDate()+3650);
      document.cookie = KEY + '=' + encodeURIComponent(JSON.stringify(obj)) + '; path=/; expires=' + exp.toUTCString();
    } catch(e){}
  }

  function shouldShow() {
    if (maxShows <= 0) return false;
    var d = getData();
    if (!d || typeof d.count!=='number' || typeof d.last!=='number') d = {count:0,last:0};
    if (d.count < maxShows) return true;
    if (resetDays > 0) {
      var deltaDays = days(now() - d.last);
      if (deltaDays >= resetDays) return true;
    }
    return false;
  }

  function closeIt(){
    var ov = document.getElementById('brb-popup-overlay');
    if (!ov) return;
    ov.style.display = 'none';
    if (autoTimer) { clearTimeout(autoTimer); autoTimer = null; }
  }

  function scheduleAutoClose(){
    if (autoClose > 0) {
      if (autoTimer) { clearTimeout(autoTimer); }
      autoTimer = setTimeout(closeIt, autoClose);
    }
  }

  function showPopup() {
    var ov = document.getElementById('brb-popup-overlay');
    if (!ov) return;
    ov.style.display = 'block';
    ov.focus();
    var d = getData();
    d.count = (d.count||0) + 1;
    d.last = now();
    setData(d);

    ov.addEventListener('click', function(e){ if (e.target === ov) closeIt(); }, false);
    document.getElementById('brb-popup-close').addEventListener('click', closeIt, false);
    document.addEventListener('keydown', function(e){ if (e.key === 'Escape') closeIt(); }, false);

    scheduleAutoClose();
  }

  if (shouldShow()) {
    if (delayMs > 0) setTimeout(showPopup, delayMs);
    else showPopup();
  }
})();
</script>
<?php endif; ?>

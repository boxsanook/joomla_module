<?php
defined('_JEXEC') or die;

require_once __DIR__ . '/helper.php';

/** @var JRegistry $params */
$ribbonEnable     = (int) $params->get('ribbon_enable', 1);
$ribbonUrl        = trim((string) $params->get('ribbon_url', '')); // optional override
$position         = $params->get('position', 'top-right');
$width            = $params->get('width', '90px');
$height           = $params->get('height', '90px');
$zIndex           = $params->get('z_index', 9999);
$description      = $params->get('description', '');

$grayEnable       = (int) $params->get('grayscale_enable', 0);
$grayAmountParam  = $params->get('grayscale_amount', 100);
$grayAmount       = is_numeric($grayAmountParam) ? (int)$grayAmountParam : 100;

// Popup params
$popupEnable      = (int) $params->get('popup_enable', 0);
$popupImgUrl      = trim((string) $params->get('popup_image_url', ''));
$popupWidth       = trim((string) $params->get('popup_width', '720px'));
$popupHeight      = trim((string) $params->get('popup_height', 'auto'));
$popupMaxShows    = (int) $params->get('popup_max_shows', 1);
$popupResetDays   = (int) $params->get('popup_reset_days', 30);
$popupDelayMs     = (int) $params->get('popup_delay_ms', 300);
$popupAutoCloseMs = (int) $params->get('popup_auto_close_ms', 0);
$popupCloseText   = (string) $params->get('popup_close_text', 'Close');
$popupBgOpacity   = (float) $params->get('popup_bg_opacity', 0.8);
$popupClickUrl    = trim((string) $params->get('popup_click_url', ''));

$root = JUri::root();

// If no override URL, choose built-in by position
if ($ribbonUrl === '') {
    switch ($position) {
        case 'top-left':
            $ribbonUrl = $root . 'media/mod_blackribbon/ribbon-top-left.svg';
            break;
        case 'bottom-right':
            $ribbonUrl = $root . 'media/mod_blackribbon/ribbon-bottom-right.svg';
            break;
        case 'bottom-left':
            $ribbonUrl = $root . 'media/mod_blackribbon/ribbon-bottom-left.svg';
            break;
        case 'top-right':
        default:
            $ribbonUrl = $root . 'media/mod_blackribbon/ribbon-top-right.svg';
            break;
    }
}

if ($popupImgUrl === '') {
    $popupImgUrl = $root . 'media/mod_blackribbon/popup-default.svg';
}

// Hide module title automatically
$module->showtitle = 0;

// Layout
require JModuleHelper::getLayoutPath('mod_blackribbon', $params->get('layout', 'default'));

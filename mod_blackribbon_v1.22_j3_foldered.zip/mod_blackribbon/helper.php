<?php
defined('_JEXEC') or die;

class ModBlackRibbonHelper {
    public static function sanitizePosition($position) {
        $allowed = array('top-left', 'top-right', 'bottom-left', 'bottom-right');
        return in_array($position, $allowed) ? $position : 'top-right';
    }

    public static function sanitizeInt($value, $min = 0, $max = 2147483647, $fallback = 9999) {
        if (!is_numeric($value)) return (int)$fallback;
        $v = (int)$value;
        if ($v < $min) $v = $min;
        if ($v > $max) $v = $max;
        return $v;
    }
}
